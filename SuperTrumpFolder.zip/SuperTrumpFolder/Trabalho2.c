#include <stdio.h>
#include "biblioteca.h"

main()
{
	Car *c = NULL;
	int n, nos = 0;//numero de participantes, nos = numero total de nos
	
	char cd[] = "A1", nom[] = "Acis";
	c = inseri(c, cd, nom, 300, 200, 100, 200);

	strcpy(cd, "B2");
	strcpy(nom, "Aderito");
	c = inseri(c, cd, nom, 100, 400, 200, 300);

	strcpy(cd, "C3");
	strcpy(nom, "Admetus");
	c = inseri(c, cd, nom, 233, 322, 123, 50);

	strcpy(cd, "D4");
	strcpy(nom, "Calista");
	c = inseri(c, cd, nom, 50, 200, 500, 60);

	strcpy(cd, "A2");
	strcpy(nom, "Carissa");
	c = inseri(c, cd, nom, 221, 200, 100, 400);

	strcpy(cd, "B3");
	strcpy(nom, "Circe");
	c = inseri(c, cd, nom, 312, 220, 170, 240);

	strcpy(cd, "C4");
	strcpy(nom, "Evanth");
	c = inseri(c, cd, nom, 200, 90, 341, 222);

	strcpy(cd, "D5");
	strcpy(nom, "Fedora");
	c = inseri(c, cd, nom, 119, 500, 50, 125);

	strcpy(cd, "A3");
	strcpy(nom, "Gelasia");
	c = inseri(c, cd, nom, 400, 101, 105, 150);

	strcpy(cd, "B4");
	strcpy(nom, "Gerasimos");
	c = inseri(c, cd, nom, 60, 200, 150, 250);

	strcpy(cd, "C5");
	strcpy(nom, "Gregorios");
	c = inseri(c, cd, nom, 66, 166, 279, 200);

	strcpy(cd, "D6");
	strcpy(nom, "Haldis");
	c = inseri(c, cd, nom, 510, 40, 220, 420);

	strcpy(cd, "A4");
	strcpy(nom, "Hekuba");
	c = inseri(c, cd, nom, 111, 222, 333, 100);

	strcpy(cd, "B5");
	strcpy(nom, "Helle");
	c = inseri(c, cd, nom, 231, 200, 50, 50);

	strcpy(cd, "D1");
	strcpy(nom, "Herakles");
	c = inseri(c, cd, nom, 300, 254, 242, 500);		
	
	strcpy(cd, "C7");
	strcpy(nom, "Jocasta");
	c = inseri(c, cd, nom, 500, 500, 200, 200);
	
	strcpy(cd, "A5");
	strcpy(nom, "Iole");
	c = inseri(c, cd, nom, 100, 60, 402, 50);

	strcpy(cd, "B6");
	strcpy(nom, "Ismena");
	c = inseri(c, cd, nom, 50, 30, 600, 40);

	strcpy(cd, "D7");
	strcpy(nom, "Hercules");
	c = inseri(c, cd, nom, 400, 199, 399, 79);

	strcpy(cd, "C6");
	strcpy(nom, "Justina");
	c = inseri(c, cd, nom, 221, 323, 125, 100);

	strcpy(cd, "A6");
	strcpy(nom, "Latona");
	c = inseri(c, cd, nom, 210, 80, 300, 420);

	strcpy(cd, "B7");
	strcpy(nom, "Maur");
	c = inseri(c, cd, nom, 30, 200, 500, 400);

	strcpy(cd, "C1");
	strcpy(nom, "Megara");
	c = inseri(c, cd, nom, 88, 108, 308, 100);
	
	strcpy(cd, "D2");
	strcpy(nom, "Melos");
	c = inseri(c, cd, nom, 160, 200, 360, 40);

	strcpy(cd, "A7");
	strcpy(nom, "Neona");
	c = inseri(c, cd, nom, 220, 100, 200, 202);

	strcpy(cd, "B1");
	strcpy(nom, "Nox");
	c = inseri(c, cd, nom, 400, 300, 500, 500);

	strcpy(cd, "C2");
	strcpy(nom, "Olimpia");
	c = inseri(c, cd, nom, 250, 350, 150, 220);

	strcpy(cd, "D3");
	strcpy(nom, "Oracle");
	c = inseri(c, cd, nom, 220, 40, 300, 40);

	strcpy(cd, "A8");
	strcpy(nom, "Pallas");
	c = inseri(c, cd, nom, 400, 100, 200, 50);
	
	strcpy(cd, "B8");
	strcpy(nom, "Philon");
	c = inseri(c, cd, nom, 200, 50, 200, 155);
	
	strcpy(cd, "C8");
	strcpy(nom, "Seferino");
	c = inseri(c, cd, nom, 100, 80, 80, 200);
	
	strcpy(cd, "D8");
	strcpy(nom, "Simeona");
	c = inseri(c, cd, nom, 500, 90, 100, 360);
	int i, ID;//recebo o ID do ganhador
	
	printf("Quantos competidores?\n");
	scanf("%d",&n);
	while(nos == 0)
	{
		for(i = 0; i < n; i++)
		{
			if(n == 1)
			{
				nos = 0;
			}
			else if(n == pow(2, i))
			{
				nos++;
			}
		}
		if(nos == 0)
		{
			printf("Digite novamente os competidores.(numeros de potencia de 2.  <2, 4, 8, 16, 32...>)\n");
			scanf("%d",&n);
		}		
	}
	Pe part[n];//Crio um vetor de pessoas, para cadastrar cada uma 
	inserirPar(part, n);//inserir participantes
	Pe ganhadores[(n * 2) - 1];
	tabela(n, part, ganhadores);//criar a arvore do campeonato
	ID = Distribuir(c, part, n, ganhadores);//recebo o ID para a pesquisa binaria
	//printf("ID = %d\n",ID);
//	puts(ganhadores[0].nome);
	system("pause");
	Pesquisa(part, ID, n/2, n/2);
	free(c);
}
